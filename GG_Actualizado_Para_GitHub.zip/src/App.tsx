import React, { useState, useEffect, useRef, useCallback } from 'react';
import { BookCollection, ReelShort } from './types';
import { DEFAULT_BOOK_COLLECTIONS } from './data/defaultBooks';
import { ReelCard } from './components/ReelCard';
import { VideoCanvasPlayer } from './components/VideoCanvasPlayer';
import { HeaderBar } from './components/HeaderBar';
import { QuizModal } from './components/QuizModal';
import { DeepDiveModal } from './components/DeepDiveModal';
import { UploadModal } from './components/UploadModal';
import { LibraryModal } from './components/LibraryModal';
import { ViralTrendsModal } from './components/ViralTrendsModal';
import { MusicSelectorModal } from './components/MusicSelectorModal';
import { BottomNav, NavTab } from './components/BottomNav';
import { SearchTab } from './components/SearchTab';
import { ProfileTab } from './components/ProfileTab';
import { HomeTab } from './components/HomeTab';
import { UploadTab } from './components/UploadTab';
import { speechService, SpeechPlayerState } from './utils/speechService';
import { soundManager } from './utils/audioEffects';
import { musicEngine, MusicTrackId } from './utils/bgmSynthesizer';
import { ViralWebTrend } from './types';
import {
  ChevronDown,
  ChevronUp,
  Sparkles,
  HelpCircle,
  Volume2,
  BookOpen,
  Keyboard,
  Compass,
  Flame
} from 'lucide-react';

export default function App() {
  // Navigation Tab State
  const [currentTab, setCurrentTab] = useState<NavTab>('reels');

  // Collections state
  const [collections, setCollections] = useState<BookCollection[]>(() => {
    try {
      const saved = localStorage.getItem('scrolllearn_collections');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {}
    return DEFAULT_BOOK_COLLECTIONS;
  });

  // Default to 'all' so books are automatically interleaved and varied across down-scrolls
  const [currentCollectionId, setCurrentCollectionId] = useState<string>('all');
  const [shuffleSeed, setShuffleSeed] = useState<number>(0);

  const [currentReelIndex, setCurrentReelIndex] = useState<number>(0);

  // Audio state
  const [isAudioPlaying, setIsAudioPlaying] = useState<boolean>(false);
  const [audioProgress, setAudioProgress] = useState<number>(0);
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState<number>(0);
  const [autoPlayAudio, setAutoPlayAudio] = useState<boolean>(false);

  // Auto-scroll Hands-Free Mode
  const [autoScroll, setAutoScroll] = useState<boolean>(false);

  // View Mode: 'card' (interactive vertical cards) | 'video' (60FPS animated video with kinetic captions)
  const [viewMode, setViewMode] = useState<'card' | 'video'>('card');

  // Music & Reel Soundtrack state
  const [activeTrackId, setActiveTrackId] = useState<MusicTrackId>('phonk');
  const [isMusicPlaying, setIsMusicPlaying] = useState<boolean>(true);
  const [isMusicSelectorOpen, setIsMusicSelectorOpen] = useState<boolean>(false);

  // Modals state
  const [activeQuizShort, setActiveQuizShort] = useState<ReelShort | null>(null);
  const [activeDeepDiveShort, setActiveDeepDiveShort] = useState<ReelShort | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState<boolean>(false);
  const [isLibraryModalOpen, setIsLibraryModalOpen] = useState<boolean>(false);
  const [isViralTrendsOpen, setIsViralTrendsOpen] = useState<boolean>(false);
  const [viralTrendForUpload, setViralTrendForUpload] = useState<string>('');

  // Gamification & Saved
  const [quizPoints, setQuizPoints] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('scrolllearn_xp')) || 10;
    } catch {
      return 10;
    }
  });

  const [savedShortIds, setSavedShortIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('scrolllearn_saved');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Compute interleaved shorts across all collections (alternating 1 from each book)
  const interleavedShorts = React.useMemo(() => {
    const result: ReelShort[] = [];
    const maxLen = Math.max(...collections.map((c) => c.shorts.length), 0);

    const activeColls = [...collections];
    if (shuffleSeed > 0) {
      activeColls.sort((a, b) => {
        const hashA = (a.id.length * 31 + shuffleSeed * 19) % 100;
        const hashB = (b.id.length * 31 + shuffleSeed * 19) % 100;
        return hashA - hashB;
      });
    }

    for (let i = 0; i < maxLen; i++) {
      for (const c of activeColls) {
        if (c.shorts[i]) {
          result.push(c.shorts[i]);
        }
      }
    }
    return result;
  }, [collections, shuffleSeed]);

  // Current active collection & shorts
  const isInterleavedMode = currentCollectionId === 'all';

  const currentCollection: BookCollection = isInterleavedMode
    ? {
        id: 'all',
        title: '🔀 Para Ti (Libros Alternados)',
        author: `${collections.length} Libros en Variación`,
        category: 'Feed Alternado',
        summary: 'Reels intercalados de todos tus libros y PDFs para máxima variedad y aprendizaje continuo.',
        coverGradient: 'from-amber-600 via-rose-700 to-indigo-900',
        shorts: interleavedShorts,
      }
    : collections.find((c) => c.id === currentCollectionId) || collections[0];

  const shorts = isInterleavedMode ? interleavedShorts : currentCollection.shorts;
  const currentShort = shorts[currentReelIndex] || shorts[0];

  // Touch gesture tracking for vertical swipe
  const touchStartY = useRef<number>(0);
  const touchEndY = useRef<number>(0);
  const isWheeling = useRef<boolean>(false);
  const wheelTimeout = useRef<number | null>(null);

  // Save collections to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('scrolllearn_collections', JSON.stringify(collections));
    } catch (e) {}
  }, [collections]);

  // Save XP to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('scrolllearn_xp', String(quizPoints));
    } catch (e) {}
  }, [quizPoints]);

  // Save Bookmarks to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('scrolllearn_saved', JSON.stringify(savedShortIds));
    } catch (e) {}
  }, [savedShortIds]);

  // All saved shorts
  const allSavedShorts = React.useMemo(() => {
    const list: ReelShort[] = [];
    collections.forEach((c) => {
      c.shorts.forEach((s) => {
        if (savedShortIds.includes(s.id)) {
          list.push(s);
        }
      });
    });
    return list;
  }, [collections, savedShortIds]);

  // Handle Reel Navigation
  const handleNextReel = useCallback(() => {
    if (currentReelIndex < shorts.length - 1) {
      soundManager.playSwoosh();
      speechService.stop();
      setIsAudioPlaying(false);
      setCurrentReelIndex((prev) => prev + 1);
    }
  }, [currentReelIndex, shorts.length]);

  const handlePrevReel = useCallback(() => {
    if (currentReelIndex > 0) {
      soundManager.playSwoosh();
      speechService.stop();
      setIsAudioPlaying(false);
      setCurrentReelIndex((prev) => prev - 1);
    }
  }, [currentReelIndex]);

  // Shuffle Feed
  const handleShuffleFeed = () => {
    soundManager.playPop();
    setShuffleSeed((prev) => prev + 1);
    setCurrentReelIndex(0);
    speechService.stop();
    setIsAudioPlaying(false);
  };

  // Select reel from Search / Home / Profile tabs
  const handleSelectReelFromTab = (short: ReelShort, collectionId: string) => {
    speechService.stop();
    setIsAudioPlaying(false);
    if (collectionId === 'all') {
      setCurrentCollectionId('all');
      const idx = interleavedShorts.findIndex((s) => s.id === short.id);
      setCurrentReelIndex(Math.max(0, idx));
    } else {
      setCurrentCollectionId(collectionId);
      const parent = collections.find((c) => c.id === collectionId);
      if (parent) {
        const idx = parent.shorts.findIndex((s) => s.id === short.id);
        setCurrentReelIndex(Math.max(0, idx));
      }
    }
    setCurrentTab('reels');
  };

  // Toggle Save / Bookmark
  const handleToggleSave = () => {
    soundManager.playPop();
    const id = currentShort.id;
    setSavedShortIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleRemoveSaved = (shortId: string) => {
    soundManager.playPop();
    setSavedShortIds((prev) => prev.filter((id) => id !== shortId));
  };

  // Add new collection generated by Gemini
  const handleAddCollection = (newColl: BookCollection) => {
    setCollections((prev) => [newColl, ...prev]);
    setCurrentCollectionId(newColl.id);
    setCurrentReelIndex(0);
  };

  const handleAddCollectionFromUpload = (newColl: BookCollection) => {
    handleAddCollection(newColl);
    setCurrentTab('reels');
  };

  // Auto-scroll Timer Effect
  useEffect(() => {
    if (!autoScroll || currentTab !== 'reels') return;
    const duration = isAudioPlaying ? 35000 : 15000;
    const timer = setTimeout(() => {
      if (currentReelIndex < shorts.length - 1) {
        handleNextReel();
      } else {
        setAutoScroll(false);
      }
    }, duration);

    return () => clearTimeout(timer);
  }, [autoScroll, currentReelIndex, shorts.length, handleNextReel, isAudioPlaying, currentTab]);

  // Audio Speech Service Setup & Ducking
  const handleToggleAudio = useCallback(() => {
    soundManager.playPop();
    if (isAudioPlaying) {
      speechService.stop();
      setIsAudioPlaying(false);
      musicEngine.setDucking(false);
    } else {
      if (!currentShort) return;
      speechService.speakReel(currentShort, {
        onStateChange: (state: SpeechPlayerState) => {
          setIsAudioPlaying(state.isPlaying);
          setAudioProgress(state.progress);
          setCurrentPhraseIndex(state.currentPhraseIndex);
          musicEngine.setDucking(state.isPlaying);
        },
        onEnd: () => {
          setIsAudioPlaying(false);
          setAudioProgress(100);
          musicEngine.setDucking(false);
        },
      });
    }
  }, [isAudioPlaying, currentShort]);

  // Keyboard navigation
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (currentTab !== 'reels') return;
      if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        handleNextReel();
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        e.preventDefault();
        handlePrevReel();
      } else if (e.key === ' ' || e.key === 'Spacebar') {
        e.preventDefault();
        handleToggleAudio();
      } else if (e.key === 'q' || e.key === 'Q') {
        e.preventDefault();
        if (currentShort) setActiveQuizShort(currentShort);
      }
    },
    [handleNextReel, handlePrevReel, handleToggleAudio, currentShort, currentTab]
  );

  // Swipe gesture handling for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    if (currentTab !== 'reels') return;
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (currentTab !== 'reels') return;
    touchEndY.current = e.changedTouches[0].clientY;
    const diff = touchStartY.current - touchEndY.current;

    // Minimum swipe threshold (50px)
    if (diff > 50) {
      handleNextReel();
    } else if (diff < -50) {
      handlePrevReel();
    }
  };

  // Mouse wheel scroll handling
  const handleWheel = (e: React.WheelEvent) => {
    if (currentTab !== 'reels') return;
    if (isWheeling.current) return;

    if (Math.abs(e.deltaY) > 40) {
      isWheeling.current = true;
      if (e.deltaY > 0) {
        handleNextReel();
      } else {
        handlePrevReel();
      }

      if (wheelTimeout.current) clearTimeout(wheelTimeout.current);
      wheelTimeout.current = window.setTimeout(() => {
        isWheeling.current = false;
      }, 650);
    }
  };

  // Start BGM on first interaction
  useEffect(() => {
    const handleFirstClick = () => {
      if (isMusicPlaying) {
        musicEngine.start('phonk');
      }
      window.removeEventListener('click', handleFirstClick);
    };
    window.addEventListener('click', handleFirstClick, { once: true });
    return () => window.removeEventListener('click', handleFirstClick);
  }, [isMusicPlaying]);

  return (
    <div
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onWheel={handleWheel}
      className="relative h-screen h-[100dvh] w-full bg-zinc-950 text-white flex flex-col justify-between overflow-hidden font-sans select-none focus:outline-none"
    >
      {/* Scrollable Container for Tabs: Inicio, Buscar, Subir, Perfil */}
      {currentTab !== 'reels' && (
        <div className="flex-1 w-full h-[calc(100dvh-58px)] overflow-y-auto overflow-x-hidden overscroll-contain">
          {/* Tab 1: Inicio */}
          {currentTab === 'home' && (
            <HomeTab
              collections={collections}
              onSelectCollection={(colId) => {
                setCurrentCollectionId(colId);
                setCurrentReelIndex(0);
                setCurrentTab('reels');
              }}
              onOpenLibrary={() => setIsLibraryModalOpen(true)}
              onOpenUpload={() => setCurrentTab('upload')}
              onPlayReel={handleSelectReelFromTab}
              quizPoints={quizPoints}
              onAddPoints={(pts) => setQuizPoints((prev) => prev + pts)}
            />
          )}

          {/* Tab 2: Buscar / Explorar */}
          {currentTab === 'search' && (
            <SearchTab
              collections={collections}
              onSelectReel={handleSelectReelFromTab}
            />
          )}

          {/* Tab 3: Subir */}
          {currentTab === 'upload' && (
            <UploadTab
              onAddCollection={handleAddCollectionFromUpload}
              onJumpToReels={() => setCurrentTab('reels')}
            />
          )}

          {/* Tab 5: Perfil / Guardados */}
          {currentTab === 'profile' && (
            <ProfileTab
              quizPoints={quizPoints}
              collections={collections}
              savedShorts={allSavedShorts}
              onSelectReel={handleSelectReelFromTab}
              onRemoveSaved={handleRemoveSaved}
              isMusicPlaying={isMusicPlaying}
              onToggleMusic={() => {
                soundManager.playPop();
                setIsMusicPlaying(!isMusicPlaying);
              }}
            />
          )}
        </div>
      )}

      {/* Tab 4: Reels (Down-scrolling view matching Screenshots 1 & 4) */}
      {currentTab === 'reels' && (
        <>
          <HeaderBar
            collections={collections}
            currentCollection={currentCollection}
            onSelectCollection={(id) => {
              setCurrentCollectionId(id);
              setCurrentReelIndex(0);
              speechService.stop();
              setIsAudioPlaying(false);
            }}
            onOpenUpload={() => setCurrentTab('upload')}
            onOpenLibrary={() => setIsLibraryModalOpen(true)}
            onOpenViralTrends={() => setIsViralTrendsOpen(true)}
            onOpenMusicSelector={() => setIsMusicSelectorOpen(true)}
            isMusicPlaying={isMusicPlaying}
            musicTrackName={musicEngine.getCurrentTrack().name}
            autoScroll={autoScroll}
            onToggleAutoScroll={() => {
              soundManager.playPop();
              setAutoScroll(!autoScroll);
            }}
            isMuted={!isAudioPlaying}
            onToggleMute={handleToggleAudio}
            quizPoints={quizPoints}
            viewMode={viewMode}
            onToggleViewMode={() => {
              soundManager.playPop();
              setViewMode(viewMode === 'card' ? 'video' : 'card');
            }}
            isInterleaved={isInterleavedMode}
            onShuffleFeed={handleShuffleFeed}
          />

          {/* Main App Canvas */}
          <div className="relative flex-1 pt-14 pb-16 px-2 sm:px-4 flex items-center justify-center overflow-hidden">
            {/* Center Vertical Reel Stage */}
            <div className="relative w-full h-[calc(100vh-130px)] max-h-[760px] max-w-[420px] flex items-center justify-center">
              {viewMode === 'video' ? (
                <VideoCanvasPlayer
                  key={`vid-${currentShort.id}`}
                  short={{
                    ...currentShort,
                    isSaved: savedShortIds.includes(currentShort.id),
                  }}
                  onNextReel={handleNextReel}
                  onPrevReel={handlePrevReel}
                  onOpenMusicSelector={() => setIsMusicSelectorOpen(true)}
                />
              ) : (
                <ReelCard
                  key={currentShort.id}
                  short={{
                    ...currentShort,
                    isSaved: savedShortIds.includes(currentShort.id),
                  }}
                  index={currentReelIndex}
                  total={shorts.length}
                  isActive={true}
                  isAudioPlaying={isAudioPlaying}
                  audioProgress={audioProgress}
                  currentPhraseIndex={currentPhraseIndex}
                  onToggleAudio={handleToggleAudio}
                  onOpenQuiz={() => setActiveQuizShort(currentShort)}
                  onOpenDeepDive={() => setActiveDeepDiveShort(currentShort)}
                  onToggleSave={handleToggleSave}
                  onNextReel={handleNextReel}
                  onPrevReel={handlePrevReel}
                  isMusicPlaying={isMusicPlaying}
                  musicTrackName={musicEngine.getCurrentTrack().name}
                  onToggleMusic={() => {
                    soundManager.playPop();
                    setIsMusicPlaying(!isMusicPlaying);
                  }}
                  onOpenMusicSelector={() => setIsMusicSelectorOpen(true)}
                />
              )}
            </div>
          </div>
        </>
      )}

      {/* Persistent Bottom Navigation Bar (5 tabs) */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        savedCount={savedShortIds.length}
      />

      {/* Modals */}
      {activeQuizShort && (
        <QuizModal
          quiz={activeQuizShort.quiz}
          reelTitle={activeQuizShort.title}
          isOpen={!!activeQuizShort}
          onClose={() => setActiveQuizShort(null)}
          onCorrect={() => {
            setQuizPoints((prev) => prev + 10);
          }}
        />
      )}

      {activeDeepDiveShort && (
        <DeepDiveModal
          short={activeDeepDiveShort}
          isOpen={!!activeDeepDiveShort}
          onClose={() => setActiveDeepDiveShort(null)}
        />
      )}

      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onAddCollection={handleAddCollectionFromUpload}
        initialViralTrend={viralTrendForUpload}
      />

      <ViralTrendsModal
        isOpen={isViralTrendsOpen}
        onClose={() => setIsViralTrendsOpen(false)}
        currentBookTitle={currentCollection.title}
        onApplyTrendToGenerator={(trend) => {
          setViralTrendForUpload(trend.trendName);
          setIsUploadModalOpen(true);
        }}
      />

      <MusicSelectorModal
        isOpen={isMusicSelectorOpen}
        onClose={() => setIsMusicSelectorOpen(false)}
        activeTrackId={activeTrackId}
        onSelectTrack={(trackId) => {
          setActiveTrackId(trackId);
          musicEngine.switchTrack(trackId);
        }}
        isMusicPlaying={isMusicPlaying}
        onToggleMusicPlay={() => {
          setIsMusicPlaying(!isMusicPlaying);
        }}
      />

      <LibraryModal
        isOpen={isLibraryModalOpen}
        onClose={() => setIsLibraryModalOpen(false)}
        collections={collections}
        currentCollectionId={currentCollectionId}
        onSelectCollection={(id) => {
          setCurrentCollectionId(id);
          setCurrentReelIndex(0);
          speechService.stop();
          setIsAudioPlaying(false);
        }}
        savedShorts={allSavedShorts}
        onSelectShort={(s) => {
          const parent = collections.find((c) => c.shorts.some((item) => item.id === s.id));
          if (parent) {
            handleSelectReelFromTab(s, parent.id);
          }
        }}
        onDeleteCollection={(id) => {
          setCollections((prev) => prev.filter((c) => c.id !== id));
          if (currentCollectionId === id) {
            setCurrentCollectionId('babilonia');
            setCurrentReelIndex(0);
          }
        }}
        quizPoints={quizPoints}
      />
    </div>
  );
}
