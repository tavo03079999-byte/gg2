import React, { useState, useRef } from 'react';
import { UploadCloud, FileText, Sparkles, BookOpen, Zap, ArrowRight, Loader2, AlertCircle, X, Check } from 'lucide-react';
import { BookCollection } from '../types';
import { soundManager } from '../utils/audioEffects';

interface UploadTabProps {
  onAddCollection: (collection: BookCollection) => void;
  onJumpToReels: () => void;
}

export const UploadTab: React.FC<UploadTabProps> = ({
  onAddCollection,
  onJumpToReels,
}) => {
  const [tab, setTab] = useState<'file' | 'book' | 'text'>('file');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [bookTitle, setBookTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [rawText, setRawText] = useState('');
  const [count, setCount] = useState<number>(5);
  const [tone, setTone] = useState<string>('⚡ Dinámico & Viral');
  const [viralTrend, setViralTrend] = useState<string>('');
  const [useWebSearch, setUseWebSearch] = useState<boolean>(true);
  const [loading, setLoading] = useState(false);
  const [currentStepText, setCurrentStepText] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      if (!bookTitle) {
        const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        setBookTitle(cleanName);
      }
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
      if (!bookTitle) {
        const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        setBookTitle(cleanName);
      }
    }
  };

  const readFileAsBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const res = reader.result as string;
        const base64 = res.split(',')[1] || res;
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const readFileAsText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsText(file);
    });
  };

  const handleGenerate = async () => {
    soundManager.playPop();
    setErrorMessage(null);

    if (tab === 'file' && !selectedFile) {
      setErrorMessage('Por favor selecciona o arrastra un archivo PDF, DOCX, EPUB o TXT.');
      return;
    }
    if (tab === 'book' && !bookTitle) {
      setErrorMessage('Por favor indica el título del libro.');
      return;
    }
    if (tab === 'text' && !rawText) {
      setErrorMessage('Por favor escribe o pega el contenido del texto.');
      return;
    }

    setLoading(true);

    try {
      setCurrentStepText('Extrayendo contenido del documento...');
      let fileData: string | undefined = undefined;
      let textContent: string | undefined = undefined;

      if (tab === 'file' && selectedFile) {
        if (selectedFile.type === 'application/pdf') {
          fileData = await readFileAsBase64(selectedFile);
        } else {
          try {
            textContent = await readFileAsText(selectedFile);
          } catch {
            fileData = await readFileAsBase64(selectedFile);
          }
        }
      } else if (tab === 'text') {
        textContent = rawText;
      }

      setCurrentStepText('Analizando sabiduría y diseñando ganchos virales con Gemini...');

      const response = await fetch('/api/generate-shorts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bookTitle: bookTitle.trim() || selectedFile?.name || 'Libro Sin Título',
          author: author.trim() || 'Autor',
          fileData,
          fileName: selectedFile?.name,
          fileType: selectedFile?.type,
          rawText: textContent,
          count,
          tone,
          viralTrend,
          useWebSearch,
        }),
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || `Error del servidor (${response.status})`);
      }

      setCurrentStepText('Estructurando lecciones interactivas y cuestionarios...');
      const data = await response.json();

      if (!data.success || !data.collection) {
        throw new Error(data.error || 'No se pudo generar la colección.');
      }

      soundManager.playSuccessChime();
      onAddCollection(data.collection);
      onJumpToReels();
    } catch (err: any) {
      soundManager.playErrorTone();
      setErrorMessage(err?.message || 'Error al conectar con la IA. Asegúrate de tener configurada tu GEMINI_API_KEY en el backend.');
    } finally {
      setLoading(false);
      setCurrentStepText('');
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto px-4 pt-4 pb-28 text-white animate-fade-in">
      <div className="p-5 sm:p-6 rounded-3xl bg-zinc-900/90 border border-zinc-800 shadow-2xl space-y-5">
        {/* Header matching Screenshot 3 */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
            <Zap className="w-6 h-6 fill-amber-400" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-black text-white">
              Crear Reels de tu PDF o Libro
            </h2>
            <p className="text-xs text-zinc-400">
              Convierte cualquier archivo en Shorts educativos con down-scrolling
            </p>
          </div>
        </div>

        {/* Sub-tabs matching Screenshot 3 */}
        <div className="flex gap-2 p-1 bg-zinc-850 rounded-2xl text-xs font-semibold">
          <button
            onClick={() => {
              soundManager.playPop();
              setTab('file');
            }}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              tab === 'file'
                ? 'bg-zinc-700 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" /> Subir PDF / Archivo
          </button>
          <button
            onClick={() => {
              soundManager.playPop();
              setTab('book');
            }}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              tab === 'book'
                ? 'bg-zinc-700 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" /> Buscar Libro
          </button>
          <button
            onClick={() => {
              soundManager.playPop();
              setTab('text');
            }}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              tab === 'text'
                ? 'bg-zinc-700 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> Pegar Texto
          </button>
        </div>

        {/* Tab 1: File Upload Drag & Drop matching Screenshot 3 */}
        {tab === 'file' && (
          <div className="space-y-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".pdf,.txt,.epub,.docx"
              className="hidden"
            />

            {!selectedFile ? (
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-zinc-700/80 hover:border-amber-500/60 rounded-3xl p-8 text-center bg-zinc-950/40 hover:bg-zinc-850/40 transition-all cursor-pointer group"
              >
                <div className="w-12 h-12 rounded-full bg-zinc-800/80 text-zinc-400 group-hover:text-amber-400 group-hover:bg-amber-500/10 mx-auto flex items-center justify-center mb-3 transition-colors">
                  <UploadCloud className="w-6 h-6" />
                </div>
                <p className="text-xs sm:text-sm font-bold text-zinc-200">
                  Arrastra tu archivo PDF aquí o haz clic para explorar
                </p>
                <p className="text-[11px] text-zinc-500 mt-1">
                  Soporta PDF, TXT, EPUB, DOCX (libros, resúmenes, apuntes)
                </p>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-zinc-800/60 border border-zinc-700/80 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-zinc-200 truncate">{selectedFile.name}</p>
                    <p className="text-[10px] text-zinc-400">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB · Listo para procesar
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedFile(null)}
                  className="p-1.5 rounded-full hover:bg-zinc-700 text-zinc-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Book Title & Author */}
        {tab === 'book' && (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Título del Libro *</label>
              <input
                type="text"
                value={bookTitle}
                onChange={(e) => setBookTitle(e.target.value)}
                placeholder="Ej: Piense y Hágase Rico, Meditaciones, El Ego es el Enemigo..."
                className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Autor (Opcional)</label>
              <input
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="Ej: Napoleon Hill, Marco Aurelio, Ryan Holiday..."
                className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>
        )}

        {/* Tab 3: Paste Text */}
        {tab === 'text' && (
          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1">Contenido o Resumen *</label>
            <textarea
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Pega aquí los capítulos, notas, artículos o reflexiones que quieras convertir en lecciones cortas..."
              rows={5}
              className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>
        )}

        {/* Dropdowns Row matching Screenshot 3 */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1.5">Cantidad de Reels</label>
            <select
              value={count}
              onChange={(e) => setCount(Number(e.target.value))}
              className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl px-3 py-2 text-xs font-semibold text-zinc-200 focus:outline-none focus:ring-1 focus:ring-amber-500 cursor-pointer"
            >
              <option value={3}>3 Reels</option>
              <option value={5}>5 Reels (Recomendado)</option>
              <option value={8}>8 Reels</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1.5">Estilo de Narración</label>
            <select
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl px-3 py-2 text-xs font-semibold text-zinc-200 focus:outline-none focus:ring-1 focus:ring-amber-500 cursor-pointer"
            >
              <option value="⚡ Dinámico & Viral">⚡ Dinámico & Viral</option>
              <option value="📖 Storytelling">📖 Storytelling</option>
              <option value="🎓 Micro-Clase">🎓 Micro-Clase</option>
              <option value="🧠 Mindset & Hábitos">🧠 Mindset & Hábitos</option>
            </select>
          </div>
        </div>

        {/* Adaptar a Formato Viral de la Web matching Screenshot 3 */}
        <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/90 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Adaptar a Formato Viral de la Web
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300">
              Google Search
            </span>
          </div>

          <input
            type="text"
            value={viralTrend}
            onChange={(e) => setViralTrend(e.target.value)}
            placeholder="Ej: POV Brutal, Regla de los 3 Segundos, Desafío 10%..."
            className="w-full bg-zinc-900 border border-zinc-700/80 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
          />

          <label className="flex items-center gap-2 cursor-pointer pt-0.5">
            <input
              type="checkbox"
              checked={useWebSearch}
              onChange={(e) => setUseWebSearch(e.target.checked)}
              className="w-3.5 h-3.5 rounded text-amber-500 focus:ring-amber-400 accent-amber-500"
            />
            <span className="text-[11px] text-zinc-400 font-medium">
              Buscar en la web formatos populares de Reels para enriquecer el guión
            </span>
          </label>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <p className="flex-1">{errorMessage}</p>
          </div>
        )}

        {/* Generation Progress Indicator */}
        {loading && (
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-center space-y-2 animate-pulse">
            <Loader2 className="w-6 h-6 animate-spin text-amber-400 mx-auto" />
            <p className="text-xs font-bold text-amber-300">{currentStepText || 'Generando con Gemini AI...'}</p>
            <p className="text-[10px] text-zinc-400">Creando ganchos, frases cinéticas y cuestionarios interactivos</p>
          </div>
        )}

        {/* CTA Submit Button matching Screenshot 3 */}
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full py-3.5 px-4 rounded-2xl font-black text-xs sm:text-sm text-zinc-950 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 transition-all shadow-lg shadow-amber-500/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-zinc-950" />
              <span>Generando Reels Educativos...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 fill-zinc-950" />
              <span>Crear Feed de Shorts con IA</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
