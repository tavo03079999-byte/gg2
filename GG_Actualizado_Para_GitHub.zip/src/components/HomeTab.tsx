import React, { useState } from 'react';
import {
  Flame,
  Clock,
  Target,
  Gift,
  Check,
  Sparkles,
  BookOpen,
  PlusCircle,
  Play,
  ChevronRight,
  Zap
} from 'lucide-react';
import { BookCollection, ReelShort } from '../types';
import { soundManager } from '../utils/audioEffects';

interface HomeTabProps {
  collections: BookCollection[];
  onSelectCollection: (collectionId: string) => void;
  onOpenLibrary: () => void;
  onOpenUpload: () => void;
  onPlayReel: (short: ReelShort, collectionId: string) => void;
  quizPoints: number;
  onAddPoints?: (points: number) => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  collections,
  onSelectCollection,
  onOpenLibrary,
  onOpenUpload,
  onPlayReel,
  quizPoints,
  onAddPoints,
}) => {
  // Streak state
  const [hasCheckedIn, setHasCheckedIn] = useState(false);
  const [streakDays, setStreakDays] = useState(5);

  // Learning Time state
  const [goalMinutes, setGoalMinutes] = useState<number>(25);
  const [learnedMinutes, setLearnedMinutes] = useState<number>(18);

  // Missions state
  const [claimedMissions, setClaimedMissions] = useState<string[]>([]);
  const [claimedChest, setClaimedChest] = useState(false);

  // Calculations for Learning Time
  const progressPercent = Math.min(100, Math.round((learnedMinutes / goalMinutes) * 100));
  const remainingMinutes = Math.max(0, goalMinutes - learnedMinutes);

  // Handle Check-in
  const handleCheckIn = () => {
    if (hasCheckedIn) return;
    soundManager.playSuccessChime();
    setHasCheckedIn(true);
    setStreakDays((prev) => prev + 1);
    if (onAddPoints) onAddPoints(20);
  };

  // Handle +5 min Sprint
  const handleAddSprint = () => {
    soundManager.playPop();
    setLearnedMinutes((prev) => prev + 5);
    if (onAddPoints) onAddPoints(5);
  };

  // Handle Claim Mission
  const handleClaimMission = (missionId: string, xp: number) => {
    if (claimedMissions.includes(missionId)) return;
    soundManager.playSuccessChime();
    setClaimedMissions((prev) => [...prev, missionId]);
    if (onAddPoints) onAddPoints(xp);
  };

  // Handle Claim Chest
  const handleClaimChest = () => {
    if (claimedChest) return;
    soundManager.playSuccessChime();
    setClaimedChest(true);
    if (onAddPoints) onAddPoints(50);
  };

  const daysOfWeek = [
    { label: 'Lun', active: true },
    { label: 'Mar', active: true },
    { label: 'Mié', active: true },
    { label: 'Jue', active: true },
    { label: 'Vie', active: true, isToday: true },
    { label: 'Sáb', active: false },
    { label: 'Dom', active: false },
  ];

  return (
    <div className="w-full max-w-2xl mx-auto px-4 pt-4 pb-28 text-white animate-fade-in space-y-5">
      {/* ========================================================
          CARD 1: RACHA ACTIVA (Daily Streak)
          ======================================================== */}
      <div className="relative rounded-[28px] p-5 sm:p-6 bg-zinc-900/90 border border-amber-500/40 shadow-xl space-y-4 overflow-hidden">
        {/* Ambient Top-Right Glow */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Header row */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
              <Flame className="w-5 h-5 fill-amber-400 text-amber-400" />
            </div>

            <div>
              <span className="text-[11px] font-black tracking-wider uppercase text-amber-400 block mb-0.5">
                RACHA ACTIVA
              </span>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  {streakDays} Días Seguidos
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[11px] font-bold flex items-center gap-1">
                  <Flame className="w-3 h-3 fill-amber-400 text-amber-400" /> x1.5 XP
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-1 font-medium">
                Completa tu check-in diario para mantener encendida la llama del hábito.
              </p>
            </div>
          </div>

          {/* Check-in Button */}
          <button
            onClick={handleCheckIn}
            disabled={hasCheckedIn}
            className={`px-3.5 sm:px-4 py-2 rounded-xl font-black text-xs transition-all flex items-center gap-1.5 shrink-0 shadow-md ${
              hasCheckedIn
                ? 'bg-zinc-800 text-zinc-400 border border-zinc-700 cursor-default'
                : 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-zinc-950 shadow-amber-500/25 active:scale-95'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${hasCheckedIn ? 'text-zinc-500' : 'fill-current'}`} />
            <span>{hasCheckedIn ? '¡Listo! (+20 XP)' : 'Check-in (+20 XP)'}</span>
          </button>
        </div>

        {/* 7-Day Streak Tracker */}
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2.5 pt-1">
          {daysOfWeek.map((day, idx) => (
            <div
              key={idx}
              className={`rounded-2xl p-2 sm:p-2.5 flex flex-col items-center justify-center transition-all ${
                day.isToday
                  ? 'bg-amber-950/30 border-2 border-amber-500 shadow-md shadow-amber-500/20'
                  : day.active
                  ? 'bg-zinc-850/80 border border-zinc-700/60'
                  : 'bg-zinc-900/50 border border-zinc-800/60 opacity-60'
              }`}
            >
              <span className={`text-[11px] font-bold mb-1.5 ${day.isToday ? 'text-amber-300' : 'text-zinc-400'}`}>
                {day.label}
              </span>

              {day.active ? (
                <>
                  <Flame className="w-4 h-4 fill-amber-400 text-amber-400 mb-1" />
                  <Check className="w-3 h-3 text-amber-400 font-bold" />
                </>
              ) : (
                <>
                  <div className="w-4 h-4 rounded-full border border-zinc-600 flex items-center justify-center mb-1">
                    <span className="w-1 h-1 rounded-full bg-zinc-600" />
                  </div>
                  <span className="text-[10px] text-zinc-600 font-bold">-</span>
                </>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* ========================================================
          CARD 2: TIEMPO DE APRENDIZAJE (Daily Goal & Minutes)
          ======================================================== */}
      <div className="rounded-[28px] p-5 sm:p-6 bg-zinc-900/90 border border-zinc-800/80 shadow-xl space-y-4">
        {/* Header row */}
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
              <Clock className="w-5 h-5 text-emerald-400" />
            </div>

            <div>
              <span className="text-[11px] font-black tracking-wider uppercase text-emerald-400 block mb-0.5">
                TIEMPO DE APRENDIZAJE
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                {learnedMinutes} de {goalMinutes} Minutos Hoy
              </h2>
            </div>
          </div>

          <div className="text-right">
            <span className="text-2xl sm:text-3xl font-black text-emerald-400 block leading-none">
              {progressPercent}%
            </span>
            <span className="text-[11px] text-zinc-400 font-medium">
              de tu meta diaria
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2.5 rounded-full bg-zinc-800 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Sub-bar Sprint info */}
        <div className="flex items-center justify-between text-xs">
          <span className="text-zinc-400 font-medium">
            {remainingMinutes > 0 ? `Faltan ${remainingMinutes} min para tu meta` : '¡Meta diaria completada! 🎉'}
          </span>
          <button
            onClick={handleAddSprint}
            className="font-bold text-emerald-400 hover:text-emerald-300 transition-colors active:scale-95"
          >
            + 5 min sprint
          </button>
        </div>

        {/* Adjust Goal Pills */}
        <div className="flex items-center justify-between pt-1 border-t border-zinc-800/60">
          <span className="text-xs text-zinc-400 font-semibold">
            Ajustar meta:
          </span>
          <div className="flex items-center gap-2">
            {[15, 25, 45].map((mins) => {
              const isSelected = goalMinutes === mins;
              return (
                <button
                  key={mins}
                  onClick={() => {
                    soundManager.playPop();
                    setGoalMinutes(mins);
                  }}
                  className={`px-3.5 py-1 rounded-full text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-emerald-400 text-zinc-950 shadow-md shadow-emerald-500/25 scale-105'
                      : 'bg-zinc-800/90 text-zinc-400 hover:text-white'
                  }`}
                >
                  {mins}m
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ========================================================
          CARD 3: MISIONES DEL DÍA (Daily Quests)
          ======================================================== */}
      <div className="rounded-[28px] p-5 sm:p-6 bg-zinc-900/90 border border-zinc-800/80 shadow-xl space-y-3.5">
        {/* Header row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
              <Target className="w-5 h-5 text-indigo-400" />
            </div>

            <div>
              <span className="text-[11px] font-black tracking-wider uppercase text-indigo-400 block mb-0.5">
                MISIONES DEL DÍA
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Metas Diarias (3/4)
              </h2>
            </div>
          </div>

          <button
            onClick={handleClaimChest}
            className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 ${
              claimedChest
                ? 'bg-zinc-800 border-zinc-700 text-zinc-400'
                : 'bg-indigo-950/60 border-indigo-500/40 text-indigo-300 hover:bg-indigo-900/60 shadow-sm'
            }`}
          >
            <Gift className="w-3.5 h-3.5 text-indigo-400" />
            <span>{claimedChest ? 'Abierto ✓' : 'Cofre del Día'}</span>
          </button>
        </div>

        {/* 4 Quests List */}
        <div className="space-y-2.5 pt-1">
          {/* Mission 1 */}
          <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/90 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full border-2 border-emerald-400 flex items-center justify-center shrink-0 shadow-[0_0_8px_rgba(52,211,153,0.3)]">
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>

              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    Ver 3 Reels Educativos
                  </h3>
                  <span className="text-[10px] font-extrabold text-amber-400 bg-amber-500/15 px-1.5 py-0.5 rounded">
                    +15 XP
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  Desliza y aprende de 3 lecciones distintas
                </p>
              </div>
            </div>

            <button
              onClick={() => handleClaimMission('m1', 15)}
              disabled={claimedMissions.includes('m1')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1 shrink-0 ${
                claimedMissions.includes('m1')
                  ? 'bg-zinc-800 text-zinc-500 cursor-default'
                  : 'bg-amber-400 hover:bg-amber-300 text-zinc-950 shadow-md shadow-amber-500/20 active:scale-95'
              }`}
            >
              <Sparkles className="w-3 h-3 fill-current" />
              <span>{claimedMissions.includes('m1') ? 'Reclamado' : 'Reclamar'}</span>
            </button>
          </div>

          {/* Mission 2 */}
          <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/90 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full border-2 border-emerald-400 flex items-center justify-center shrink-0 shadow-[0_0_8px_rgba(52,211,153,0.3)]">
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>

              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    Superar 1 Quiz de Conocimiento
                  </h3>
                  <span className="text-[10px] font-extrabold text-amber-400 bg-amber-500/15 px-1.5 py-0.5 rounded">
                    +20 XP
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  Acierta la trivia financiera o de hábitos
                </p>
              </div>
            </div>

            <button
              onClick={() => handleClaimMission('m2', 20)}
              disabled={claimedMissions.includes('m2')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1 shrink-0 ${
                claimedMissions.includes('m2')
                  ? 'bg-zinc-800 text-zinc-500 cursor-default'
                  : 'bg-amber-400 hover:bg-amber-300 text-zinc-950 shadow-md shadow-amber-500/20 active:scale-95'
              }`}
            >
              <Sparkles className="w-3 h-3 fill-current" />
              <span>{claimedMissions.includes('m2') ? 'Reclamado' : 'Reclamar'}</span>
            </button>
          </div>

          {/* Mission 3 */}
          <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/90 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full border-2 border-emerald-400 flex items-center justify-center shrink-0 shadow-[0_0_8px_rgba(52,211,153,0.3)]">
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>

              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    Escuchar con Narrador de Voz
                  </h3>
                  <span className="text-[10px] font-extrabold text-amber-400 bg-amber-500/15 px-1.5 py-0.5 rounded">
                    +15 XP
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  Activa la voz en off para aprendizaje auditivo
                </p>
              </div>
            </div>

            <button
              onClick={() => handleClaimMission('m3', 15)}
              disabled={claimedMissions.includes('m3')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1 shrink-0 ${
                claimedMissions.includes('m3')
                  ? 'bg-zinc-800 text-zinc-500 cursor-default'
                  : 'bg-amber-400 hover:bg-amber-300 text-zinc-950 shadow-md shadow-amber-500/20 active:scale-95'
              }`}
            >
              <Sparkles className="w-3 h-3 fill-current" />
              <span>{claimedMissions.includes('m3') ? 'Reclamado' : 'Reclamar'}</span>
            </button>
          </div>

          {/* Mission 4 (Pending) */}
          <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/90 flex items-center justify-between gap-3 opacity-80">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full border-2 border-zinc-700 flex items-center justify-center shrink-0">
                <div className="w-1.5 h-1.5 rounded-full bg-zinc-700" />
              </div>

              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    Consultar al Mentor IA
                  </h3>
                  <span className="text-[10px] font-extrabold text-amber-400 bg-amber-500/15 px-1.5 py-0.5 rounded">
                    +15 XP
                  </span>
                </div>
                <p className="text-[11px] text-zinc-500">
                  Toca el botón IA en un Reel para profundizar
                </p>
              </div>
            </div>

            <span className="text-xs font-bold text-zinc-500 px-3">
              0/1
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================
          QUICK ACCESS & BOOK COLLECTIONS (Convenience footer)
          ======================================================== */}
      <div className="grid grid-cols-2 gap-3 pt-2">
        <button
          onClick={() => {
            soundManager.playPop();
            onOpenLibrary();
          }}
          className="p-3.5 rounded-2xl bg-zinc-900/90 hover:bg-zinc-850 border border-zinc-800 hover:border-amber-500/40 text-left transition-all group flex items-center justify-between"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500/20">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-zinc-200">Biblioteca</p>
              <p className="text-[10px] text-zinc-500">{collections.length} Libros</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-amber-400 transition-colors" />
        </button>

        <button
          onClick={() => {
            soundManager.playPop();
            onOpenUpload();
          }}
          className="p-3.5 rounded-2xl bg-zinc-900/90 hover:bg-zinc-850 border border-zinc-800 hover:border-amber-500/40 text-left transition-all group flex items-center justify-between"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500/20">
              <PlusCircle className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-zinc-200">Subir Archivo</p>
              <p className="text-[10px] text-zinc-500">Crear reels</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-amber-400 transition-colors" />
        </button>
      </div>
    </div>
  );
};
