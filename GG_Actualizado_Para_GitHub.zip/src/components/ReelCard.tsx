import React, { useState } from 'react';
import {
  Heart,
  Volume2,
  VolumeX,
  HelpCircle,
  Sparkles,
  Bookmark,
  Share2,
  Check,
  Bot,
  ChevronDown,
  ChevronUp,
  Music,
  Disc3,
  BookOpen
} from 'lucide-react';
import { ReelShort } from '../types';
import { soundManager } from '../utils/audioEffects';

interface ReelCardProps {
  short: ReelShort;
  index: number;
  total: number;
  isActive: boolean;
  isAudioPlaying: boolean;
  audioProgress: number;
  currentPhraseIndex: number;
  onToggleAudio: () => void;
  onOpenQuiz: () => void;
  onOpenDeepDive: () => void;
  onToggleSave: () => void;
  onNextReel: () => void;
  onPrevReel: () => void;
  isMusicPlaying: boolean;
  musicTrackName: string;
  onToggleMusic: () => void;
  onOpenMusicSelector: () => void;
}

export const ReelCard: React.FC<ReelCardProps> = ({
  short,
  index,
  total,
  isActive,
  isAudioPlaying,
  audioProgress,
  onToggleAudio,
  onOpenQuiz,
  onOpenDeepDive,
  onToggleSave,
  onNextReel,
  onPrevReel,
  isMusicPlaying,
  musicTrackName,
  onToggleMusic,
  onOpenMusicSelector,
}) => {
  const [likes, setLikes] = useState(short.likes || 1240);
  const [hasLiked, setHasLiked] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleLike = () => {
    soundManager.playPop();
    if (hasLiked) {
      setLikes((prev) => prev - 1);
      setHasLiked(false);
    } else {
      setLikes((prev) => prev + 1);
      setHasLiked(true);
    }
  };

  const handleCopy = async () => {
    soundManager.playPop();
    const textToCopy = `💡 "${short.title}" (${short.bookTitle} - ${short.author})\n\n"${short.hook}"\n\n🎯 Acción de hoy: ${short.actionableTakeaway}`;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch (e) {
      // fallback
    }
  };

  return (
    <div
      className="relative w-full h-full max-w-[420px] mx-auto rounded-[32px] overflow-hidden flex flex-col justify-between select-none border border-amber-500/30 bg-zinc-950 transition-all duration-300"
      style={{
        boxShadow: isActive
          ? '0 0 50px rgba(245, 158, 11, 0.22), 0 0 100px rgba(0,0,0,0.85)'
          : '0 0 30px rgba(0,0,0,0.8)',
      }}
    >
      {/* Dynamic ambient background glow */}
      <div className="absolute -top-20 -left-20 w-64 h-64 rounded-full blur-3xl pointer-events-none opacity-20 bg-amber-500/30" />
      <div className="absolute -bottom-20 -right-20 w-64 h-64 rounded-full blur-3xl pointer-events-none opacity-15 bg-amber-600/20" />

      {/* Top Header Bar */}
      <div className="relative z-10 pt-4 px-5 pb-1">
        {/* Progress Bar (Stories-style dash segments) */}
        <div className="flex items-center gap-1.5 mb-2.5">
          {Array.from({ length: total }).map((_, i) => (
            <div
              key={i}
              className="h-1 flex-1 rounded-full bg-white/20 overflow-hidden"
            >
              <div
                className={`h-full transition-all duration-300 ${
                  i < index
                    ? 'w-full bg-amber-400'
                    : i === index
                    ? 'w-full bg-amber-400 shadow-[0_0_8px_#f59e0b]'
                    : 'w-0'
                }`}
                style={{
                  width:
                    i === index && isAudioPlaying
                      ? `${audioProgress * 100}%`
                      : i <= index
                      ? '100%'
                      : '0%',
                }}
              />
            </div>
          ))}
        </div>

        {/* Source metadata: BOOK TITLE . 45s and index */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 truncate text-amber-400 font-extrabold text-[11px] sm:text-xs tracking-wider uppercase">
            <BookOpen className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate max-w-[240px]">
              {short.bookTitle}
            </span>
            <span className="text-zinc-500">.</span>
            <span className="text-amber-400/90 font-bold shrink-0">
              {short.readTime || '45s'}
            </span>
          </div>

          <div className="bg-white/10 px-2 py-0.5 rounded-full border border-white/10 text-[11px] font-bold text-zinc-300 shrink-0">
            {index + 1}/{total}
          </div>
        </div>
      </div>

      {/* Main Reel Content Stage */}
      <div className="relative z-10 flex-1 px-5 py-1.5 flex flex-col justify-center overflow-hidden">
        {/* Title */}
        <div className="mb-2">
          <h2 className="text-xl sm:text-2xl font-black text-white leading-tight drop-shadow-md">
            {short.title}
          </h2>
          <p className="text-xs text-zinc-400 font-semibold mt-0.5">
            Por {short.author}
          </p>
        </div>

        {/* The Hook Box (Gancho del Reel) */}
        <div className="relative my-2 p-3.5 rounded-2xl bg-zinc-900/90 backdrop-blur-md border border-zinc-800/90 shadow-lg">
          <div className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider text-amber-400 mb-1">
            <span className="text-sm">👌</span> GANCHO DEL REEL
          </div>
          <p className="text-sm sm:text-[15px] font-bold text-white italic leading-snug drop-shadow-sm">
            "{short.hook}"
          </p>
        </div>

        {/* 3 Actionable Steps */}
        <div className="space-y-2 my-2">
          {short.steps.slice(0, 3).map((step, sIdx) => (
            <div
              key={sIdx}
              className="flex items-start gap-2.5 text-xs sm:text-[13px] text-zinc-200"
            >
              <div className="w-5 h-5 rounded-full shrink-0 flex items-center justify-center font-bold text-[11px] text-amber-400 bg-zinc-900 border border-zinc-700/80 shadow-sm mt-0.5">
                {sIdx + 1}
              </div>
              <p className="leading-tight font-medium text-zinc-200/95">{step}</p>
            </div>
          ))}
        </div>

        {/* Actionable Takeaway (Aplica Esto Hoy) */}
        <div className="my-2 p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/40 text-amber-100 shadow-md">
          <div className="flex items-center gap-1.5 text-[11px] font-extrabold text-amber-400 uppercase tracking-wide mb-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" /> APLICA ESTO HOY:
          </div>
          <p className="text-xs sm:text-[13px] font-medium text-zinc-100 leading-snug">
            {short.actionableTakeaway}
          </p>
        </div>
      </div>

      {/* Bottom Area: Chevrons + Music Pill */}
      <div className="relative z-10 px-5 pb-4 pt-1 flex items-center justify-between">
        {/* Prev / Next Navigation Chevrons */}
        <div className="flex flex-col gap-1.5">
          <button
            onClick={onPrevReel}
            disabled={index === 0}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white flex items-center justify-center disabled:opacity-20 disabled:pointer-events-none transition-all active:scale-90"
            title="Reel anterior (Flecha Arriba)"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <button
            onClick={onNextReel}
            disabled={index === total - 1}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white flex items-center justify-center disabled:opacity-20 disabled:pointer-events-none transition-all active:scale-90"
            title="Siguiente Reel (Flecha Abajo)"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>

        {/* Music Sound Ticker Pill */}
        <div
          onClick={onOpenMusicSelector}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/10 hover:border-amber-500/40 cursor-pointer transition-all max-w-[270px] group"
          title="Toca para cambiar la música"
        >
          <div
            className={`w-5 h-5 rounded-full bg-zinc-800 border border-amber-500/40 flex items-center justify-center shrink-0 ${
              isMusicPlaying ? 'animate-spin' : ''
            }`}
            style={{ animationDuration: '3s' }}
          >
            <Disc3 className="w-3.5 h-3.5 text-amber-400" />
          </div>

          <div className="truncate text-left">
            <p className="text-[10px] font-bold text-white truncate flex items-center gap-1 leading-tight">
              <Music className="w-2.5 h-2.5 text-amber-400 shrink-0" />
              {musicTrackName || 'Phonk Motivación Viral'}
            </p>
            <p className="text-[8.5px] text-zinc-400 truncate leading-tight">
              Audio original alternado - GG ✝
            </p>
          </div>
        </div>
      </div>

      {/* Right Floating Interaction Sidebar (Exact order as in screenshot) */}
      <div className="absolute right-3.5 top-1/2 -translate-y-1/2 z-20 flex flex-col items-center gap-3">
        {/* 1. Like Button */}
        <button
          onClick={handleLike}
          className="flex flex-col items-center group transition-transform active:scale-75"
          aria-label="Dar me gusta"
        >
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md border transition-all ${
              hasLiked
                ? 'bg-rose-600/90 border-rose-500 text-white shadow-lg shadow-rose-500/30'
                : 'bg-black/40 border-white/20 text-white hover:bg-black/60'
            }`}
          >
            <Heart
              className={`w-5 h-5 ${hasLiked ? 'fill-current text-white' : ''}`}
            />
          </div>
          <span className="text-[10px] font-bold text-white mt-1 drop-shadow-md">
            {likes}
          </span>
        </button>

        {/* 2. Interactive Quiz Button (with golden notification dot) */}
        <button
          onClick={onOpenQuiz}
          className="flex flex-col items-center group transition-transform active:scale-75"
          aria-label="Hacer quiz"
        >
          <div className="relative w-10 h-10 rounded-full flex items-center justify-center bg-black/40 hover:bg-black/60 backdrop-blur-md border border-white/20 text-white">
            <HelpCircle className="w-5 h-5 text-white" />
            <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-amber-400 rounded-full border-2 border-zinc-950 shadow-[0_0_6px_#f59e0b]" />
          </div>
          <span className="text-[10px] font-semibold text-white mt-1 drop-shadow-md">
            Quiz
          </span>
        </button>

        {/* 3. Deep Dive AI Button */}
        <button
          onClick={onOpenDeepDive}
          className="flex flex-col items-center group transition-transform active:scale-75"
          aria-label="Preguntar a la IA"
        >
          <div className="w-10 h-10 rounded-full flex items-center justify-center bg-black/40 hover:bg-black/60 backdrop-blur-md border border-white/20 text-white">
            <Bot className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-semibold text-white mt-1 drop-shadow-md">
            IA
          </span>
        </button>

        {/* 4. Music Track Selector Button */}
        <button
          onClick={onOpenMusicSelector}
          className="flex flex-col items-center group transition-transform active:scale-75"
          aria-label="Música de fondo"
        >
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md border transition-all ${
              isMusicPlaying
                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                : 'bg-black/40 border-white/20 text-white hover:bg-black/60'
            }`}
          >
            <Music className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-semibold text-white mt-1 drop-shadow-md">
            Música
          </span>
        </button>

        {/* 5. Audio / Mute Button */}
        <button
          onClick={onToggleAudio}
          className="flex flex-col items-center group transition-transform active:scale-75"
          aria-label="Audio narración"
        >
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md border transition-all ${
              isAudioPlaying
                ? 'bg-amber-500 border-amber-400 text-zinc-950 shadow-lg shadow-amber-500/40 animate-pulse'
                : 'bg-black/40 border-white/20 text-white hover:bg-black/60'
            }`}
          >
            {isAudioPlaying ? (
              <Volume2 className="w-5 h-5" />
            ) : (
              <VolumeX className="w-5 h-5" />
            )}
          </div>
          <span className="text-[10px] font-semibold text-white mt-1 drop-shadow-md">
            {isAudioPlaying ? 'Voz' : 'Mute'}
          </span>
        </button>

        {/* 6. Bookmark / Save Button */}
        <button
          onClick={onToggleSave}
          className="flex flex-col items-center group transition-transform active:scale-75"
          aria-label="Guardar lección"
        >
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md border transition-all ${
              short.isSaved
                ? 'bg-amber-500 border-amber-400 text-zinc-950'
                : 'bg-black/40 border-white/20 text-white hover:bg-black/60'
            }`}
          >
            <Bookmark
              className={`w-5 h-5 ${short.isSaved ? 'fill-current' : ''}`}
            />
          </div>
          <span className="text-[10px] font-semibold text-white mt-1 drop-shadow-md">
            Guardar
          </span>
        </button>

        {/* 7. Share / Copy Action */}
        <button
          onClick={handleCopy}
          className="flex flex-col items-center group transition-transform active:scale-75"
          aria-label="Compartir lección"
        >
          <div className="w-10 h-10 rounded-full flex items-center justify-center bg-black/40 hover:bg-black/60 backdrop-blur-md border border-white/20 text-white">
            {copied ? (
              <Check className="w-5 h-5 text-emerald-400" />
            ) : (
              <Share2 className="w-5 h-5" />
            )}
          </div>
          <span className="text-[10px] font-semibold text-white mt-1 drop-shadow-md">
            {copied ? 'Copiado' : 'Copiar'}
          </span>
        </button>
      </div>
    </div>
  );
};
