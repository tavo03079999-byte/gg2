import React from 'react';
import {
  BookOpen,
  Sparkles,
  Disc3,
  Shuffle,
  ChevronDown
} from 'lucide-react';
import { BookCollection } from '../types';

interface HeaderBarProps {
  collections: BookCollection[];
  currentCollection: BookCollection;
  onSelectCollection: (id: string) => void;
  onOpenUpload: () => void;
  onOpenLibrary: () => void;
  onOpenViralTrends: () => void;
  onOpenMusicSelector: () => void;
  isMusicPlaying: boolean;
  musicTrackName: string;
  autoScroll: boolean;
  onToggleAutoScroll: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  quizPoints: number;
  viewMode: 'card' | 'video';
  onToggleViewMode: () => void;
  isInterleaved: boolean;
  onShuffleFeed?: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  collections,
  currentCollection,
  onSelectCollection,
  onOpenMusicSelector,
  isMusicPlaying,
  musicTrackName,
  quizPoints,
  isInterleaved,
  onShuffleFeed,
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-zinc-950/90 backdrop-blur-xl border-b border-zinc-800/60 px-3 sm:px-6 py-2.5">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
        {/* Left: Branding GG ✝ + GG ✝ REELS badge */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-black/60 border border-amber-500/30 rounded-xl p-1 pr-2 shadow-sm">
            <div className="w-7 h-7 rounded-lg bg-amber-400 flex items-center justify-center font-black text-zinc-950 text-xs shadow-sm">
              GG ✝
            </div>
            <span className="text-[10px] font-mono font-extrabold text-amber-400 tracking-wider">
              GG ✝ REELS
            </span>
          </div>
        </div>

        {/* Center: Collection / Feed Selector Dropdown + Shuffle Button */}
        <div className="flex items-center gap-1.5">
          <div className="relative flex items-center bg-zinc-900 border border-zinc-700/80 hover:border-amber-500/50 rounded-full px-3 py-1.5 text-xs text-zinc-200 transition-colors">
            <BookOpen className="w-3.5 h-3.5 text-amber-400 mr-1.5 shrink-0" />
            <select
              value={currentCollection.id}
              onChange={(e) => onSelectCollection(e.target.value)}
              className="bg-transparent text-xs font-semibold text-zinc-200 focus:outline-none appearance-none pr-5 cursor-pointer max-w-[140px] sm:max-w-[200px] truncate"
            >
              <option value="all" className="bg-zinc-900 text-amber-300 font-bold">
                Para Ti (Alternado)
              </option>
              {collections.map((c) => (
                <option key={c.id} value={c.id} className="bg-zinc-900 text-white">
                  {c.title}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-zinc-400 absolute right-2.5 pointer-events-none" />
          </div>

          {onShuffleFeed && (
            <button
              onClick={onShuffleFeed}
              className="p-1.5 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-zinc-300 hover:text-amber-400 transition-colors"
              title="Mezclar y alternar el orden de los reels"
            >
              <Shuffle className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Right: Music Track Pill + XP Points Pill */}
        <div className="flex items-center gap-2">
          {/* Music Selector Pill */}
          <button
            onClick={onOpenMusicSelector}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all active:scale-95 ${
              isMusicPlaying
                ? 'bg-amber-500/10 border-amber-500/40 text-amber-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
            }`}
            title="Música de fondo"
          >
            <Disc3
              className={`w-3.5 h-3.5 text-amber-400 ${isMusicPlaying ? 'animate-spin' : ''}`}
              style={{ animationDuration: '3s' }}
            />
            <span className="truncate max-w-[70px] sm:max-w-[100px] text-[11px] font-bold">
              {musicTrackName || 'Phonk Motiv...'}
            </span>
          </button>

          {/* XP Points Pill */}
          <div
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs font-extrabold shadow-sm"
            title="Puntos de Quiz acumulados"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{quizPoints || 10}</span>
          </div>
        </div>
      </div>
    </header>
  );
};
