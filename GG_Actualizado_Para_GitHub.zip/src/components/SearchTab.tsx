import React, { useState, useMemo } from 'react';
import { Search, Play, BookOpen, Sparkles, X } from 'lucide-react';
import { BookCollection, ReelShort } from '../types';
import { soundManager } from '../utils/audioEffects';

interface SearchTabProps {
  collections: BookCollection[];
  onSelectReel: (short: ReelShort, collectionId: string) => void;
}

const CATEGORY_CHIPS = [
  'Todos',
  'Riqueza Personal',
  'Control de Gastos',
  'Inversión Inteligente',
  'Interés Compuesto',
  'Habilidades & Mentalidad',
  'Mejora Continua',
  'Anti-Procrastinación',
  'Transformación Mental',
  'Filosofía Financiera',
];

export const SearchTab: React.FC<SearchTabProps> = ({
  collections,
  onSelectReel,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');

  // Flatten all reels from all collections
  const allReels = useMemo(() => {
    const list: Array<{ short: ReelShort; collection: BookCollection }> = [];
    collections.forEach((c) => {
      c.shorts.forEach((s) => {
        list.push({ short: s, collection: c });
      });
    });
    return list;
  }, [collections]);

  // Filter reels based on search query and category
  const filteredReels = useMemo(() => {
    return allReels.filter(({ short, collection }) => {
      const q = searchQuery.toLowerCase().trim();

      const matchesCategory =
        selectedCategory === 'Todos' ||
        (short.category && short.category.toLowerCase().includes(selectedCategory.toLowerCase())) ||
        (collection.category && collection.category.toLowerCase().includes(selectedCategory.toLowerCase())) ||
        (short.title && short.title.toLowerCase().includes(selectedCategory.toLowerCase()));

      if (!matchesCategory) return false;

      if (!q) return true;

      const inTitle = short.title?.toLowerCase().includes(q);
      const inHook = short.hook?.toLowerCase().includes(q);
      const inBook = short.bookTitle?.toLowerCase().includes(q) || collection.title?.toLowerCase().includes(q);
      const inAuthor = short.author?.toLowerCase().includes(q) || collection.author?.toLowerCase().includes(q);
      const inInsight = short.coreInsight?.toLowerCase().includes(q);
      const inQuote = short.quote?.toLowerCase().includes(q);

      return inTitle || inHook || inBook || inAuthor || inInsight || inQuote;
    });
  }, [allReels, searchQuery, selectedCategory]);

  const handlePlayReel = (short: ReelShort, collectionId: string) => {
    soundManager.playPop();
    onSelectReel(short, collectionId);
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 pt-6 pb-28 text-white animate-fade-in">
      {/* Header */}
      <div className="mb-5">
        <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
          <Search className="w-6 h-6 text-amber-400" />
          Explorar y Buscar Reels
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400 mt-1">
          Encuentra lecciones por tema, libro o título
        </p>
      </div>

      {/* Search Input Bar */}
      <div className="relative mb-4">
        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-500">
          <Search className="w-4 h-4" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Buscar 'Págate primero', 'Hábitos', 'Dinero'..."
          className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-amber-500/80 rounded-2xl pl-10 pr-10 py-3 text-xs sm:text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500 shadow-inner"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-zinc-500 hover:text-zinc-200"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Category Pills (Horizontal scrollable) */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-4">
        {CATEGORY_CHIPS.map((cat) => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => {
                soundManager.playPop();
                setSelectedCategory(cat);
              }}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 transition-all ${
                isSelected
                  ? 'bg-amber-400 text-zinc-950 font-bold shadow-md shadow-amber-500/20'
                  : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Reels Count */}
      <div className="text-xs text-zinc-400 mb-3 px-1">
        {filteredReels.length} {filteredReels.length === 1 ? 'reel encontrado' : 'reels encontrados'}
      </div>

      {/* Reels List */}
      <div className="space-y-3">
        {filteredReels.length === 0 ? (
          <div className="text-center py-12 px-4 rounded-3xl bg-zinc-900/40 border border-zinc-800/60">
            <Sparkles className="w-8 h-8 text-amber-500/50 mx-auto mb-2" />
            <p className="text-sm font-semibold text-zinc-300">No se encontraron reels</p>
            <p className="text-xs text-zinc-500 mt-1">Intenta con otra palabra clave o selecciona 'Todos'</p>
          </div>
        ) : (
          filteredReels.map(({ short, collection }) => {
            const categoryTag = (short.category || collection.category || 'Lección Clave').toUpperCase();

            return (
              <div
                key={short.id}
                onClick={() => handlePlayReel(short, collection.id)}
                className="group relative p-4 rounded-2xl bg-zinc-900/80 hover:bg-zinc-850 border border-zinc-800/80 hover:border-amber-500/40 transition-all cursor-pointer flex items-center justify-between gap-3 shadow-sm hover:shadow-md"
              >
                <div className="min-w-0 flex-1 space-y-1">
                  {/* Category & Book Name */}
                  <div className="flex items-center gap-1.5 text-[10px] font-bold tracking-wider text-amber-400">
                    <span>{categoryTag}</span>
                    <span className="text-zinc-600 font-normal">·</span>
                    <span className="text-zinc-400 font-normal truncate flex items-center gap-1">
                      <BookOpen className="w-3 h-3 text-zinc-500 shrink-0" />
                      {short.bookTitle || collection.title}
                    </span>
                  </div>

                  {/* Reel Title */}
                  <h3 className="text-sm font-black text-zinc-100 group-hover:text-amber-300 transition-colors line-clamp-1">
                    {short.title}
                  </h3>

                  {/* Quote or Hook */}
                  <p className="text-xs text-zinc-400 italic line-clamp-2 leading-relaxed">
                    "{short.hook || short.quote || short.coreInsight}"
                  </p>
                </div>

                {/* Play Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePlayReel(short, collection.id);
                  }}
                  className="w-10 h-10 rounded-full bg-zinc-800/90 group-hover:bg-amber-400 group-hover:text-zinc-950 text-zinc-300 flex items-center justify-center shrink-0 transition-all shadow-sm"
                  title="Reproducir este Reel"
                >
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
